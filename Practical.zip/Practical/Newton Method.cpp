#include<bits/stdc++.h>
using namespace std;

double f(double x,double y)
{
	return (2*x*x*x - y*y - 1);
}

double g(double x,double y)
{
	return (x*y*y*y - y -4);
}

double Dfx(double x,double y)
{
	return (6*x*x);
}

double Dfy(double x,double y)
{
	return (-2*y);
}

double Dgx(double x,double y)
{
	return (y*y*y);
}

double Dgy(double x,double y)
{
	return (3*y*y*x - 1);
}
double D(double x,double y)
{
	return (Dfx(x,y)*Dgy(x,y) - Dfy(x,y)*Dgx(x,y));
}
double Dx(double x,double y)
{
	return (f(x,y)*Dgy(x,y) - Dfy(x,y)*g(x,y));
}
double Dy(double x,double y)
{
	return (Dfx(x,y)*g(x,y) - f(x,y)*Dgx(x,y));
}

int main()
{
	double x0,x1,y0,y1,n=0;
	cout<<"\n Enter Initial Values (x0,y0):";
	cin>>x0>>y0;
	do
	{
		n++;
		if(n>100)
		{
			cout<<"\n Error: Excess looping. "; exit(0);
		}
		if(D(x0,y0)<0.00001)
		{
			cout<<"\n Error Overflow:"; exit(0);
		}
		x1 = x0 - (Dx(x0,y0)/D(x0,y0));
		y1 = y0 - (Dy(x0,y0)/D(x0,y0));
		x0 = x1; y0 = y1;

	}while((fabs(f(x0,y0))>0.000001) || (fabs(f(x0,y0))>0.000001));

	cout<<"\n Roots are : x0 = "<<x0<<", y0 = "<<y0<<"\n";
	cout<<"\n Values of f(x0,y0)="<<f(x0,y0)<<", g(x0,y0)="<<g(x0,y0)<<"\n";

	return 0;
}