#include <bits/stdc++.h>
using namespace std;

const int maxn = 100;

double eval_f(double x, double y, double z){
	return z;
}

double eval_g(double x, double y, double z){
	return (1 + x*x)*y;
}

double x[maxn], y[maxn], z[maxn], f[maxn], g[maxn];

void Runge_kutta(double at = 0.4, double x0 = 0.0, double y0 = 1.0, double z0 = 0.0){
	double h = 0.1;
	double k1, k2, k3, k4, l1, l2, l3, l4;

	double a = x0, b = y0, c = z0;
	int ct = 0;
	while( a <= at ){
		k1 = h * eval_f(a, b, c);
		l1 = h * eval_g(a, b, c);

		k2 = h * eval_f(a + h / 2, b + k1 / 2, c + l1 / 2);
		l2 = h * eval_g(a + h / 2, b + k1 / 2, c + l1 / 2);

		k3 = h * eval_f(a + h / 2, b + k2 / 2, c + l2 / 2);
		l3 = h * eval_g(a + h / 2, b + k2 / 2, c + l2 / 2);

		k4 = h * eval_f(a + h, b + k3, c + l3);
		l4 = h * eval_g(a + h, b + k3, c + l3);

		f[ct] = eval_f(a, b, c);
		g[ct] = eval_g(a, b, c);
		x[ct] = a, y[ct] = b, z[ct] = c;

		a = a + h;
		b = b + (k1 + 2.0 * (k2 + k3) + k4) / 6.0;
		c = c + (l1 + 2.0 * (l2 + l3) + l4) / 6.0;
		ct++;
	}
}

void Milne_Method(double X, double y0 = 1.0, double z0 = 0.0){
	double h, Y, Z, f4, y1, g4, z1;
	h = 0.1;
	Y = y0 + (4.0 * h / 3.0) * (2.0 * eval_f(x[1], y[1], z[1]) - eval_f(x[2], y[2], z[2]) + 2.0 * eval_f(x[3], y[3], z[3]));
	//printf("%lf\n", Y);
	Z = z0 + (4.0 * h / 3.0) * (2 * eval_g(x[1], y[1], z[1]) - eval_g(x[2], y[2], z[2]) + 2 * eval_g(x[3], y[3], z[3]));
	f4 = eval_f(X, Y, Z);
	y1 = y[2] + (h / 3) * (f[2] + 4 * f[3] + f4);
	printf("%lf\n", y1);
	g4 = eval_g(X, y1 , Z);
	//printf("%lf\n", g4); 
	z1 = z[2] + (h / 3) * (g[2] + 4 * g[3] + g4);
	printf("%lf\n", z1);

}
int main(){
	Runge_kutta();
	Milne_Method(0.4);
}