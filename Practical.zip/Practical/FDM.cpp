#include <stdio.h>

const int maxn = 101;

double mat[maxn][maxn];
double D[maxn], A[maxn], B[maxn], X[maxn];

int main(){
	// freopen("t.txt", "r", stdin);
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			scanf("%lf", &mat[i][j]);
		}
	}
	for(int i = 0; i < n; i++){
		scanf("%lf", &D[i]);
	}
	A[0] = mat[0][0], B[0] = D[0]/ mat[0][0];
	for(int i =1; i < n; i++){
		A[i] = mat[i][i] - (mat[i][i-1] * mat[i-1][i]) / A[i - 1];
		B[i] = (D[i] - mat[i][i-1] * B[i - 1]) / A[i];
	}
	X[n - 1] = B[n - 1];
	printf("%lf\n", X[n-1]);
	for(int i = n - 2; i >=0; i--){
		X[i] = B[i] - (mat[i][i + 1] * X[i +1]) / A[i];
		printf("%lf\n", X[i]);
	}
}


//1.9375
/*

input

3
-1.9375
1
0
1
-1.9375
1
0
1
-1.9375
0
0
-1

*/
